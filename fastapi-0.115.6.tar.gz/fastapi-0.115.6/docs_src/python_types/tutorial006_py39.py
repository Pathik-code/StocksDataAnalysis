def process_items(items: list[str]):
    for item in items:
        print(item)
